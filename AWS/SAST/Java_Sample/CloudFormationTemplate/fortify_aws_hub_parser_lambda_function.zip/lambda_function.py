import json
import boto3
import datetime
import os

def send_finding_security_hub(rowlist):
    # import sechub + sts boto3 client
    securityhub = boto3.client('securityhub')
    sts = boto3.client('sts')    
    
    # retrieve account id from STS GetCallerID
    getAccount = sts.get_caller_identity()
    awsAccount = str(getAccount['Account'])
    awsRegion = os.environ['AWS_REGION']
    
    print('updating vulnerabilities into SecurityHub')
    if (len(rowlist) <= 0):
        print ('Nothing to add')
    for vul in rowlist:
        # create ISO 8601 timestamp
        iso8601Time = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        # map Trivy severity to ASFF severity
        if vul['severity'] == 1:
            fortifySev = int(1)
            fortifyAsffRating = fortifySev * 10
        elif vul['severity'] == 2:
            fortifySev = int(4)
            fortifyAsffRating = fortifySev * 10
        elif vul['severity'] == 3:
            fortifySev = int(7)
            fortifyAsffRating = fortifySev * 10
        elif vul['severity'] == 4:
            fortifySev = int(9)
            fortifyAsffRating = fortifySev * 10
        else:
            print('No vulnerability information found')
        try:
            response = securityhub.batch_import_findings(
                Findings=[
                    {
                        'SchemaVersion': '2018-10-08',
                        'Id': str(vul['id']),
                        'ProductArn': "arn:aws:securityhub:"+ awsRegion +":" + awsAccount +":product/" + awsAccount +"/default", 
                        'GeneratorId': "arn:aws:securityhub:"+ awsRegion +":" + awsAccount +":product/" + awsAccount +"/default",
                        "CompanyName": "OpenText",
                        'AwsAccountId': awsAccount,
                        'Types': [ 'Software and Configuration Checks/Vulnerabilities/CVE' ],
                        'CreatedAt': iso8601Time,
                        'UpdatedAt': iso8601Time,
                        'Severity': {
                            'Original': str(vul['severity']),
                            'Normalized': fortifyAsffRating
                        },
                        'Title': vul['category'],
                        'Description': vul['all_data']['details']['summary'],
                        'Remediation': {
                            'Recommendation': {
                                'Text': (vul['all_data']['recommendations']['recommendations'][:510] + '..') if len(vul['all_data']['recommendations']['recommendations']) > 510 else vul['all_data']['recommendations']['recommendations'],
                                'Url': vul['deepLink']
                            }
                        },
                        'ProductFields': { 'Product Name': 'Fortify' },
                        'Resources': [
                            {
                                'Type': 'Application',
                                'Id': vul['release']['applicationAndReleaseName'],
                                'Partition': 'aws',
                                'Region': awsRegion,
                                'Details': {
                                    'Other': {
                                        'RELEASE ID': str(vul['releaseId']),
                                        'PRIMARY LOCATION': vul['all_data']['summary']['primaryLocationFull'],
                                        'LINE NUMBER': str(vul['all_data']['summary']['lineNumber']),
                                        'VUL ID': vul['all_data']['vulnId']
                                    }
                                }
                            },
                        ],
                        'RecordState': 'ACTIVE'
                    }
                ]
            )
            print(response)
        except Exception as e:
            print(e)
            raise
    #print(rowlist)

def lambda_handler(event, context):
    #parse json
    d1 = json.dumps(event)
    json_data = json.loads(d1)

    out_index = 0
    rowlist = []
    for vul in json_data['vulnerabilities']:
        rowlist.append(vul)
        if len(rowlist) == 90:
            #adding vulnerabilities to Security Hub
            send_finding_security_hub(rowlist)
            rowlist = []
            out_index += 1

    # dump the last batch
    if len(rowlist) > 0:
        #adding vulnerabilities to Security Hub
        send_finding_security_hub(rowlist)        

    return {
        'statusCode': 200,
        'body': len(json_data['vulnerabilities'][0])
    }
